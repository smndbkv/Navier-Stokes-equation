#include <stdio.h>
#include <fstream>
#include "grid.h"
#include "point.h"

int main(int argc, char **argv)
{
    int nx, ny;
    if (!(argc == 3 && sscanf(argv[1], "%d", &nx) == 1 && sscanf(argv[2], "%d", &ny) == 1))
    {
        printf("Usage: %s nx ny\n", argv[0]);
        return 0;
    }
    grid G(nx, ny, false);
    // G.draw_grid();
    // point p = {0.3, 0.1};
    // G.draw_point(p);
    // edge ed = G.linear_search(p);
    // G.draw_edge(ed);
    //  printf("%d\n", ed.id);
    // int k = ed.points[0]->id;
    // int k = 6;
    // G.draw_phi(k);
    // G.draw_phi_x(k);
    G.draw_u2();
    G.solve_linear_system();
    G.draw_u_approximate();
    printf("redisual_c = %10.3e\n", G.get_r_c());
    //  printf("%lf\n", G.phi(p, k));
    //  G.plot3d(0, 1, 100, 0, 1, 100);
    //  G.integral_phi_square(0);
    //  G.integral_phi(k);
    //  G.draw_point_edges(k / nx, k % nx);
    //  G.init_matr_m();
    // G.print_matr();
    return 0;
}
