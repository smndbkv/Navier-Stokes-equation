#ifndef GRID_H
#define GRID_H

#include <stdio.h>
#include <random>
#include "point.h"
#include "edge.h"
#include "const.h"

class grid
{
public:
    int nx = 0, ny = 0;
    point *points = nullptr;
    edge *edges = nullptr;
    FILE *gp = nullptr;
    int data_i = 0;
    grid(int nx, int ny, int s = 0)
    {
        this->nx = nx;
        this->ny = ny;
        points = new point[nx * ny];
        edges = new edge[(nx - 1) * (ny - 1)];
        gp = popen("gnuplot -persist", "w");
        if (!gp)
        {
            perror("popen");
            return;
        }
        fprintf(gp, "set terminal wxt size 700,700\n");
        fprintf(gp, "set title 'Сетка'\n");
        fprintf(gp, "set xrange [-0.5:1.5]\n");
        fprintf(gp, "set yrange [-0.5:1.5]\n");
        fprintf(gp, "plot NaN notitle\n");
        // fflush(gp);
        for (int i = 0; i < ny; i++)
        {
            for (int j = 0; j < nx; j++)
            {
                points[i * nx + j].init(f_x(i, j, s), f_y(i, j, s), i * nx + j);
                // printf(" (%.3lf, %.3lf)", points[i * nx + j].x, points[i * nx + j].y);
            }
            // printf("\n");
        }
        for (int i = 0; i < ny - 1; i++)
        {
            for (int j = 0; j < nx - 1; j++)
            {
                edges[i * (nx - 1) + j].init(points + i * nx + j, points + i * nx + j + 1, points + (i + 1) * nx + j + 1, points + (i + 1) * nx + j, i * (nx - 1) + j);
            }
            // printf("\n");
        }
    }
    ~grid()
    {
        nx = ny = 0;
        delete[] points;
        delete[] edges;
        pclose(gp);
    }
    double f_x(int i, int j, int s = 0)
    {
        switch (s)
        {
        case 0:
            return (double)j / (nx - 1);
        default:
            return 0;
        }
    }

    double f_y(int i, int j, int s = 0)
    {
        switch (s)
        {
        case 0:
            return (double)(ny - 1 - i) / (ny - 1);
        default:
            return 0;
        }
    }

    void draw_grid()
    {
        for (int i = 0; i < ny - 1; i++)
        {
            for (int j = 0; j < nx - 1; j++)
            {
                draw_edge(i, j, 0.7, 0);
            }
        }
    }
    void draw_edge(int i, int j, double weight = 2, double color = 1)
    {
        edge ed = edges[i * (nx - 1) + j];
        point *p0 = ed.points[0], *p1 = ed.points[1], *p2 = ed.points[2], *p3 = ed.points[3];

        // fprintf(gp, "set grid\n");

        // Передаём данные в виде блока и рисуем замкнутую линию
        fprintf(gp, "$data%d << EOD\n", data_i);
        fprintf(gp, "%lf %lf\n", p0->x, p0->y);
        fprintf(gp, "%lf %lf\n", p1->x, p1->y);
        fprintf(gp, "%lf %lf\n", p2->x, p2->y);
        fprintf(gp, "%lf %lf\n", p3->x, p3->y);
        fprintf(gp, "%lf %lf\n", p0->x, p0->y);
        fprintf(gp, "EOD\n");

        fprintf(gp, "replot $data%d with lines lw %lf lc %lf notitle \n", data_i, weight, color);
        data_i++;
        // fflush(gp);
    }
    void draw_edge(edge ed, double weight = 2, double color = 1)
    {
        point *p0 = ed.points[0], *p1 = ed.points[1], *p2 = ed.points[2], *p3 = ed.points[3];

        // fprintf(gp, "set grid\n");

        // Передаём данные в виде блока и рисуем замкнутую линию
        fprintf(gp, "$data%d << EOD\n", data_i);
        fprintf(gp, "%lf %lf\n", p0->x, p0->y);
        fprintf(gp, "%lf %lf\n", p1->x, p1->y);
        fprintf(gp, "%lf %lf\n", p2->x, p2->y);
        fprintf(gp, "%lf %lf\n", p3->x, p3->y);
        fprintf(gp, "%lf %lf\n", p0->x, p0->y);
        fprintf(gp, "EOD\n");

        fprintf(gp, "replot $data%d with lines lw %lf lc %lf notitle \n", data_i, weight, color);
        data_i++;
        // fflush(gp);
    }
    void draw_point(point &p)
    {
        fprintf(gp, "$data%d << EOD\n", data_i);
        fprintf(gp, "%lf %lf\n", p.x, p.y);
        fprintf(gp, "EOD\n");
        fprintf(gp, "replot $data%d with points pt 7 ps 1 lc 'red' notitle\n", data_i);
        data_i++;
    }
    edge linear_search(point &p)
    {
        edge ed;
        for (int i = 0; i < ny - 1; i++)
        {
            for (int j = 0; j < nx - 1; j++)
            {
                ed = edges[i * (nx - 1) + j];
                // if (ed.belongs(p))
                // {
                //     return ed;
                // }
                point polygon[4] = {*ed.points[0], *ed.points[1], *ed.points[2], *ed.points[3]};
                if (belongs_polygon(p, polygon, 4))
                {
                    return ed;
                }
            }
            // printf("\n");
        }
        return ed;
    }
    bool belongs_polygon(point &p, point *polygon, int n_pol)
    {
        bool has_positive = false;
        bool has_negative = false;

        for (int i = 0; i < n_pol; i++)
        {
            point v1 = polygon[i];
            point v2 = polygon[(i + 1) % n_pol];

            double cross = (v2.x - v1.x) * (p.y - v1.y) - (v2.y - v1.y) * (p.x - v1.x);

            if (cross > EPS)
                has_positive = true;
            if (cross < -EPS)
                has_negative = true;

            if (has_positive && has_negative)
                return false;
        }

        return true;
    }
    double plane(const point &p, const point &p0, const point &p1, const point &p2)
    {
        // Вычисляем знаменатель (ориентированная площадь треугольника p0-p1-p2, умноженная на 2)
        double denom = (p2.x - p0.x) * (p1.y - p0.y) - (p2.y - p0.y) * (p1.x - p0.x);
        // Если знаменатель близок к нулю, точки коллинеарны — решения нет
        double num = (p.x - p0.x) * (p1.y - p0.y) - (p.y - p0.y) * (p1.x - p0.x);

        return num / denom;
    }

    double phi(point &p, int k)
    {
        point p0, p1, p2, p3, p4;
        int i = k / nx, j = k % nx;
        p0 = {f_x(i - 1, j - 1), f_y(i - 1, j - 1)};
        p1 = {f_x(i - 1, j + 1), f_y(i - 1, j + 1)};
        p2 = {f_x(i + 1, j + 1), f_y(i + 1, j + 1)};
        p3 = {f_x(i + 1, j - 1), f_y(i + 1, j - 1)};
        p4 = {f_x(i, j), f_y(i, j)};
        // p0 = points[k - nx - 1];
        // p1 = points[k - nx + 1];
        // p2 = points[k + nx + 1];
        // p3 = points[k + nx - 1];
        // p4 = points[k];
        point trianle0[3] = {p0, p1, p4};
        point trianle1[3] = {p1, p2, p4};
        point trianle2[3] = {p2, p3, p4};
        point trianle3[3] = {p3, p0, p4};
        if (belongs_polygon(p, trianle0, 3))
        {
            return plane(p, p0, p1, p4);
        }
        else if (belongs_polygon(p, trianle1, 3))
        {
            return plane(p, p1, p2, p4);
        }
        else if (belongs_polygon(p, trianle2, 3))
        {
            return plane(p, p2, p3, p4);
        }
        else if (belongs_polygon(p, trianle3, 3))
        {
            return plane(p, p3, p0, p4);
        }
        return 0;
    }
    double integral_triangle(double (grid::*f)(point &p, int k), int k, point &p0, point &p1, point &p2)
    {
        double s = 0.5 * fabs((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));
        point m0, m1, m2;
        m0.init(0.5 * (p0.x + p1.x), 0.5 * (p0.y + p1.y));
        m1.init(0.5 * (p1.x + p2.x), 0.5 * (p1.y + p2.y));
        m2.init(0.5 * (p2.x + p0.x), 0.5 * (p2.y + p0.y));
        return (1. / 3) * s * ((this->*f)(m0, k) + (this->*f)(m1, k) + (this->*f)(m2, k));
    }
    double integral(double (grid::*f)(point &p, int k), int k)
    {
        double s0, s1, s2, s3;
        point p0, p1, p2, p3, p4;
        p0 = points[k - nx - 1];
        p1 = points[k - nx + 1];
        p2 = points[k + nx + 1];
        p3 = points[k + nx - 1];
        p4 = points[k];
        s0 = integral_triangle(f, k, p0, p1, p4);
        s1 = integral_triangle(f, k, p1, p2, p4);
        s2 = integral_triangle(f, k, p2, p3, p4);
        s3 = integral_triangle(f, k, p3, p0, p4);
        return s0 + s1 + s2 + s3;
    }
    double phi_square(point &p, int k)
    {
        return phi(p, k) * phi(p, k);
    }
    double integral_phi_square(int k)
    {
        printf("integral(phi^2) = %lf\n", integral(&grid::phi_square, k));
        return 0;
    }
    void plot3d(double xmin, double xmax, int nx, double ymin, double ymax, int ny, int k, const char *title = "3D plot")
    {
        // Открываем pipe в gnuplot, сохраняем указатель в gp3d
        FILE *gp3d = popen("gnuplot -persist", "w");
        if (!gp3d)
        {
            perror("popen failed");
            return;
        }

        // Настройки графика
        fprintf(gp3d, "set terminal qt enhanced font 'Verdana,10'\n");
        if (title)
        {
            fprintf(gp3d, "set title '%s'\n", title);
        }
        fprintf(gp3d, "set xlabel 'x'\n");
        fprintf(gp3d, "set ylabel 'y'\n");
        fprintf(gp3d, "set zlabel 'z'\n");
        fprintf(gp3d, "set grid\n");
        fprintf(gp3d, "set hidden3d\n");
        fprintf(gp3d, "set dgrid3d %d,%d\n", nx, ny);
        fprintf(gp3d, "set view 60,30\n");

        // Команда построения с встроенными данными
        fprintf(gp3d, "splot '-' with lines title 'f(x,y)'\n");

        // Генерация данных
        double dx = (nx > 1) ? (xmax - xmin) / (nx - 1) : 0.0;
        double dy = (ny > 1) ? (ymax - ymin) / (ny - 1) : 0.0;

        for (int j = 0; j < ny; ++j)
        {
            double y = ymin + j * dy;
            for (int i = 0; i < nx; ++i)
            {
                double x = xmin + i * dx;
                point p = {x, y};
                double z = phi_square(p, k);
                fprintf(gp3d, "%f %f %f\n", x, y, z);
            }
            fprintf(gp3d, "\n"); // разделитель блоков
        }

        fprintf(gp3d, "e\n"); // конец данных
        fflush(gp3d);         // принудительная отправка

        pclose(gp3d); // закрытие pipe
    }
};
#endif