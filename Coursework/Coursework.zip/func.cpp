#include <math.h>
#include "func.h"
#include "point.h"

double integral(double (*f)(point &p), double x0, double x1, double y0, double y1)
{
    // Узлы и веса двухточечной квадратуры Гаусса на отрезке [0,1]
    const double gauss_xi[2] = {0.5 - 0.5 / sqrt(3.0), 0.5 + 0.5 / sqrt(3.0)};
    const double gauss_w[2] = {0.5, 0.5};

    double hx = x1 - x0;
    double hy = y1 - y0;
    double result = 0.0;
    point p;
    for (int i = 0; i < 2; ++i)
    {
        double x = x0 + gauss_xi[i] * hx;
        for (int j = 0; j < 2; ++j)
        {
            double y = y0 + gauss_xi[j] * hy;
            double weight = gauss_w[i] * gauss_w[j] * hx * hy;
            p.init(x, y);
            result += weight * f(p);
        }
    }
    return result;
}