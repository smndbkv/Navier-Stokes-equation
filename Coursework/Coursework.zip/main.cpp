#include <stdio.h>
#include <fstream>
#include "grid.h"
#include "point.h"
#include "edge.h"
// #include "func.h"

// bool drawPoints(const point *points, int n)
// {
//     if (n <= 0 || points == nullptr)
//     {
//         std::cerr << "Ошибка: пустой массив точек.\n";
//         return false;
//     }

//     // Создаём временный файл с данными
//     std::ofstream data("points_data.txt");
//     if (!data.is_open())
//     {
//         std::cerr << "Не удалось создать файл points_data.txt\n";
//         return false;
//     }

//     // Записываем координаты точек (по одному на строку)
//     for (int i = 0; i < n; ++i)
//     {
//         data << points[i].x << " " << points[i].y << "\n";
//     }
//     data.close();

//     // Формируем команду для gnuplot
//     // Используем стиль points (точки) с размером 2 и типом 7 (кружки)
//     std::string command = "gnuplot -persist -e \""
//                           "plot 'points_data.txt' with points pt 7 ps 2 notitle"
//                           "\"";

//     int ret = std::system(command.c_str());
//     if (ret != 0)
//     {
//         std::cerr << "Ошибка при запуске gnuplot. Убедитесь, что gnuplot установлен и доступен в PATH.\n";
//         return false;
//     }
//     return true;
// }

int main(int argc, char **argv)
{
    int nx, ny;
    if (!(argc == 3 && sscanf(argv[1], "%d", &nx) == 1 && sscanf(argv[2], "%d", &ny) == 1))
    {
        printf("Usage: %s nx ny\n", argv[0]);
        return 0;
    }
    grid G(nx, ny);
    G.draw_grid();
    point p = {0.07, 0.6};
    G.draw_point(p);
    edge ed = G.linear_search(p);
    G.draw_edge(ed);
    printf("%d\n", ed.id);
    printf("%lf\n", G.phi(p, nx / 2 * nx + ny / 2));
    G.plot3d(0, 1, 100, 0, 1, 100, nx / 2 * nx + ny / 2);
    G.integral_phi_square(nx / 2 * nx + ny / 2);
    return 0;
}
