#ifndef FUNC_H
#define FUNC_H
#include <math.h>
#include "point.h"

double integral(double (*f)(point &p), double x0, double x1, double y0, double y1);

#endif